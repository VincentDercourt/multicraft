Place plugin files in here.

Recognized files:
*.jar: Plugin JAR files that will be copied to the servers "plugins" directory when the user clicks on "Install". Provides a "Remove" button to uninstall the plugin.
*.zip: Plugin packages that will be extracted into the servers "plugins" directory when the user clicks "Unpack". There is no uninstall functionality for .zip files.
*.txt: Description text file that provides information on the .jar or .zip with the same name (e.g. "test.jar.txt" for the plugin "test.jar"). Displayed in the servers plugin list for the appropriate entry.
