<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/mc/newdir2.template.php begin -->
<?php	for ($i=0; $i<sizeof($net2ftp_output["newdir"]); $i++) {
		echo $net2ftp_output["newdir"][$i] . "<br />\n";
	} // end for ?>
<!-- Template /skins/mc/newdir2.template.php end -->
