alter table `server_config` add `user_mysql` integer not null default 1;
