alter table `server` add `autosave` integer not null default 1;
alter table `server` add `jardir` varchar(16) not null default 'daemon';
