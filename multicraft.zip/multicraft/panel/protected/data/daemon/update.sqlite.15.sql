alter table `server` add `domain` text not null default '';
