alter table `server` add `autosave` integer not null default 1;
alter table `server` add `jardir` text not null default 'daemon';
